package com.example.myclip;

import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceManager;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    static MainActivity mainActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_main);
        handler.post(updateThread);


        mainActivity=this;
    }


    //主页动态显示时间
    Handler handler = new Handler();
    String time=null;
    Runnable updateThread = new Runnable() {
        @Override
        public void run() {
            handler.postDelayed(updateThread,1000);
            String DEFAULT_TIME_FORMAT = "yyyy-MM-dd hh:mm:ss";
            SimpleDateFormat dateFormat = new SimpleDateFormat(DEFAULT_TIME_FORMAT);
            time = dateFormat.format(Calendar.getInstance().getTime());
            TextView tv=(TextView) findViewById(R.id.tv_time);
            tv.setText(time);
        }
    };
    public void click(View v){
        Intent intent = new Intent(this,Chat.class);
        startActivity(intent);
        MainActivity.this.finish();  //跳转页面后关闭本Activity
    }


}