package com.example.myclip;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.preference.PreferenceManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

public class Chat extends AppCompatActivity{
    RecyclerView recyclerView;
    MyAdapter myAdapter;
    EditText edit;  //输入框对象
    String string;  //string是从edit对象中获取的内容
    Button btn;  //btn获取的是在recyclerview上的蒙版按钮，目的是为了点击后取消键盘的显示
    Intent intent;

    final  static int LEFT=1;
    final  static int RIGHT=2;
    int i=0;    //控制recyclerview内item显示顺序
    int position=2;  //设置显示位置默认为右边

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        btn=(Button) findViewById(R.id.btn_visi);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                keyboardUtils k=new keyboardUtils();
                k.hidekeyboard(Chat.this);
            }
        } );
        intent=new Intent(this,Music.class);

    }
    @Override
    protected void onStart() {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(this);
        boolean Music=sp.getBoolean("music",false);
        if(Music) {
            startService(intent);
            Log.i("musicStart", "背景音乐正在播放...");
        }
        else {
            stopService(intent);
            Log.i("musicStart", "背景音乐停止.");
        }
        super.onStart();
    }

    //在输入框失去焦点后关闭输入框
    public  class keyboardUtils{
        public void  hidekeyboard(Activity context){
            InputMethodManager imm=(InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(context.getWindow().getDecorView().getWindowToken(),0);
        }
    }

    //退出按钮对话框
    public Dialog addDialog(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("确定要关闭应用？").setPositiveButton("确定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                Chat.this.finish();
//                MainActivity.mainActivity.finish();

            }
        }).setNeutralButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        return builder.create();
    }

    //菜单
    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater= getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){
            case R.id.set1:
                Intent it= new Intent(this,SettingsActivity.class);
                startActivity(it);
                break;
            case R.id.set2:
                addDialog().show();
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    //初始化recyclerview
    private void initView(){
        recyclerView= (RecyclerView) findViewById(R.id.rv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        myAdapter=new MyAdapter(this);
        recyclerView.setAdapter(myAdapter);
    }

    //对话在左边显示
    public void left_speak(View v){
//        myAdapter.addItem(string+i,LEFT);
        recyclerView.smoothScrollToPosition(i);
        i++;
        position=1;
    }

    //对话在右边显示
    public void right_speak(View v){
//        myAdapter.addItem(string+i,RIGHT);
        recyclerView.smoothScrollToPosition(i);
        i++;
        position=2;
    }

    //获取输入框内容，获取输出位置（在左或在右）并在recyclerview中显示
    public void get_edit(View v){
        edit=(EditText) findViewById(R.id.edit_speak);
        string = edit.getText().toString();
        if(string.trim().length()!=0) {
            myAdapter.addItem(string, position);
        }

    }



}